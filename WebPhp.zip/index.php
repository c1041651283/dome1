<!DOCTYPE html>
<html lang="zh-CN">
<?php require_once './header.php' ?>

<body>
    <?php require_once './nav.php' ?>
    <br>
    <h5 id="title-div" class="card-header text-center">Vanilla JavaScript Single-page Application built with MSAL.js</h5>
    <h5 id="welcome-div" class="card-header text-center d-none"></h5>
    <br>
    <!-- Content -->
    <div class="card">
        <h5 class="card-header text-center">Getting an access token with Azure AD B2C and calling a Web API</h5>
        <div class="card-body text-center">
            <h5 id="label" class="card-title">Sign-in with Microsoft Azure AD B2C</h5>
            <pre id="response" class="card-text"></pre>
            <button type="button" id="callApiButton" class="btn btn-primary d-none" onclick="passTokenToApi()">Call API</button>
        </div>
    </div>
    <!-- importing bootstrap.js and supporting js libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>

</html>