<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <a class="navbar-brand" href="/">Azure AD B2C</a>
  <div class="btn-group ml-auto dropleft">
    <button type="button" id="editProfileButton" class="btn btn-secondary d-none" onclick="editProfile()">Edit Profile</button>
    <button type="button" id="signIn" class="btn btn-secondary" onclick="signIn()">Sign-in</button>
    <button type="button" id="signOut" class="btn btn-success d-none" onclick="signOut()">Sign-out</button>
  </div>
</nav>
<script type="text/javascript" src="./apiConfig.js"></script>
<script type="text/javascript" src="./policies.js"></script>
<script type="text/javascript" src="./authConfig.js"></script>
<script type="text/javascript" src="./ui.js"></script>

<!-- <script type="text/javascript" src="./authRedirect.js"></script>   -->
<!-- uncomment the above line and comment the line below if you would like to use the redirect flow -->
<script type="text/javascript" src="./authPopup.js"></script>